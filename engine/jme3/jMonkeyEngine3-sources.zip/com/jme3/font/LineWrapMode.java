package com.jme3.font;

/**
 * Line-wrap type for BitmapText
 * @author YongHoon
 */
public enum LineWrapMode {
    NoWrap,
    Character,
    Word
}
